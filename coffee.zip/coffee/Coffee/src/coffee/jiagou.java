package coffee;

public class jiagou {
	private int gou_id;
	private int gou_count;
	private int M_id;
	private int vip_id;
	public int getGou_id() {
		return gou_id;
	}
	public void setGou_id(int gou_id) {
		this.gou_id = gou_id;
	}
	public int getGou_count() {
		return gou_count;
	}
	public void setGou_count(int gou_count) {
		this.gou_count = gou_count;
	}
	public int getM_id() {
		return M_id;
	}
	public void setM_id(int m_id) {
		M_id = m_id;
	}
	public int getVip_id() {
		return vip_id;
	}
	public void setVip_id(int vip_id) {
		this.vip_id = vip_id;
	}
	@Override
	public String toString() {
		return "jiagou [gou_id=" + gou_id + ", gou_count=" + gou_count
				+ ", M_id=" + M_id + ", vip_id=" + vip_id + "]";
	}

}
