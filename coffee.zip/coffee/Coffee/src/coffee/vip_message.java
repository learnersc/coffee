package coffee;

public class vip_message {
	private int vip_id;
	private String vip_name;
	private String vip_password;
	
	public vip_message(){}
	public vip_message(String user_name, String user_password) {
		
		this.vip_name = user_name;
		this.vip_password = user_password;
	}
	public int getVip_id() {
		return vip_id;
	}
	public void setVip_id(int vip_id) {
		this.vip_id = vip_id;
	}
	public String getVip_name() {
		return vip_name;
	}
	public void setVip_name(String vip_name) {
		this.vip_name = vip_name;
	}
	public String getVip_password() {
		return vip_password;
	}
	public void setVip_password(String vip_password) {
		this.vip_password = vip_password;
	}
	@Override
	public String toString() {
		return "vip_message [vip_id=" + vip_id + ", vip_name=" + vip_name
				+ ", vip_password=" + vip_password + "]";
	}
	
}
