package coffee;

public class menu {
	private int M_id;
	private String M_menu;
	private double M_price;
	private String M_image;
	private String M_desc;
	public int getM_id() {
		return M_id;
	}
	public void setM_id(int m_id) {
		M_id = m_id;
	}
	public String getM_menu() {
		return M_menu;
	}
	public void setM_menu(String m_menu) {
		M_menu = m_menu;
	}
	public double getM_price() {
		return M_price;
	}
	public void setM_price(double m_price) {
		M_price = m_price;
	}
	public String getM_image() {
		return M_image;
	}
	public void setM_image(String m_image) {
		M_image = m_image;
	}
	public String getM_desc() {
		return M_desc;
	}
	public void setM_desc(String m_desc) {
		M_desc = m_desc;
	}
	@Override
	public String toString() {
		return "menu [M_id=" + M_id + ", M_menu=" + M_menu + ", M_price="
				+ M_price + ", M_image=" + M_image + ", M_desc=" + M_desc + "]";
	}


}
