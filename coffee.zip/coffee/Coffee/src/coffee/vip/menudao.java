package coffee.vip;

import java.util.List;

import coffee.menu;

public interface menudao {
	public List<menu> executeQuery();
public menu chaId(int ID);
}
