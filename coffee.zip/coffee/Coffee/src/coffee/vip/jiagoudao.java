package coffee.vip;

import java.util.List;

import coffee.jiagou;

public interface jiagoudao {
	public int addgou(jiagou gou);
	public int carcount(int vip_id,int M_id);
	public int updateCount(int userId, int productId,int count);
	public List<List<Object>> queryCarByUserId(int userId);
	public int delete( int gou_id);
	public int updatezeng(int gou_id);
	public int updatejian(int gou_id);
	public int deleteAll(int ID);
}
