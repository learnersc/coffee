package coffee.vip;


import java.util.List;

import coffee.jiagou;
import coffee.menu;
import coffee.vip_message;
import fengzhuang.ff.ff;

public class jiagoudaoImpl extends ff implements jiagoudao {

	@Override
	public int addgou(jiagou gou) {
		 String sql="insert into jiagou values(default,?,?,?)";
			Object[] zwf={gou.getGou_count(),gou.getM_id(),gou.getVip_id()};
			return super.zsg(sql,zwf);		
	}

	@Override
	public int carcount(int vip, int M) {
String sql="select count(*) as 'vip_id'  from jiagou where vip_id=? and M_id=?";
Object[] zwf={vip,M};
		List<jiagou> jg= super.executeQuery(sql, jiagou.class, zwf);
		if(jg.size()!=0){
			return jg.get(0).getVip_id();
		}
		return 0;
	}
	@Override
	public int updateCount(int userId, int productId,int count) {
		String sql = "update jiagou set gou_count=gou_count+? where vip_id=? and M_id=?";
		Object[] zwf = {count,userId,productId};
		return super.zsg(sql, zwf);
	}

	@Override
	public List<List<Object>> queryCarByUserId(int userId) {
		String sql = "select g.gou_id,m.M_menu,m.M_price,m.M_image,g.gou_count from menu m inner join  jiagou g on m.M_id=g.M_id and vip_id=?";
		Object[] params = {userId};
		return super.executeQuery(sql, params);
}

	@Override
	public int delete(int gou_id) {
String sql="delete from jiagou where gou_id=?";
Object[] zwf={gou_id};
		return super.zsg(sql, zwf);
	}

	@Override
	public int updatezeng(int gou_id) {
		String sql = "update jiagou set gou_count=gou_count+1 where gou_id=?";
		Object[] zwf = {gou_id};
		return super.zsg(sql, zwf);
	}

	@Override
	public int updatejian( int gou_id) {
		String sql = "update jiagou set gou_count=gou_count-1 where gou_id=?";
		Object[] zwf = {gou_id};
		return super.zsg(sql, zwf);		
	}

	@Override
	public int deleteAll(int ID) {
		String sql="delete from jiagou where vip_id=?";
		Object[] zwf = {ID};
		return super.zsg(sql, zwf);
	}
}