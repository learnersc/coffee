package coffee.vip;

import java.util.List;

import coffee.vip_message;
import fengzhuang.ff.ff;

public class vipdaoImpl extends ff implements vipdao {

	@Override
	public int addvip(vip_message vip) {
     String sql="insert into vip_message values(default,?,?)";
		Object[] zwf={vip.getVip_name(),vip.getVip_password()};
		return super.zsg(sql,zwf);
	}
	@Override
	public vip_message loginvip(String vip_name, String vip_password) {
		String sql = "select vip_id,vip_name from vip_message where vip_name=? and vip_password=?";
		Object[] params = {vip_name,vip_password};
		List<vip_message> vips = super.executeQuery(sql, vip_message.class, params);
		if(vips!=null && vips.size()!=0){
			return vips.get(0);//��ü����еĵ�һ������
		}
		return null;
	}
}
