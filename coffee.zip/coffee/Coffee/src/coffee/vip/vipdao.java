package coffee.vip;

import coffee.vip_message;

public interface  vipdao {
public int addvip(vip_message vip);
public vip_message loginvip(String vip_name,String vip_password);
}
