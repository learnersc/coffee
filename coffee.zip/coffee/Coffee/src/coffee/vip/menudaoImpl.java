package coffee.vip;

import java.util.List;

import coffee.menu;
import fengzhuang.ff.ff;

public class menudaoImpl extends ff implements menudao {

	@Override
		public List<menu> executeQuery() {
			String sql="select * from menu";
			return super.executeQuery(sql,menu.class,null);
	}
		@Override
		public menu chaId(int ID) {
			String sql="select * from menu where M_id=?";
			Object[] zwf={ID};
			List<menu> menus = super.executeQuery(sql, menu.class, zwf);
			if(menus != null && menus.size()!=0){
				return menus.get(0);//��ü����е�һ��Ԫ��
			}
		return null;
	}
}
