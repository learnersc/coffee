/*
Navicat MySQL Data Transfer

Source Server         : sxsh
Source Server Version : 50714
Source Host           : 127.0.0.1:3306
Source Database       : coffee

Target Server Type    : MYSQL
Target Server Version : 50714
File Encoding         : 65001

Date: 2018-07-17 16:58:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for jiagou
-- ----------------------------
DROP TABLE IF EXISTS `jiagou`;
CREATE TABLE `jiagou` (
  `gou_id` int(11) NOT NULL AUTO_INCREMENT,
  `gou_count` int(11) NOT NULL,
  `M_id` int(11) NOT NULL,
  `vip_id` int(11) NOT NULL,
  PRIMARY KEY (`gou_id`),
  KEY `M_id` (`M_id`),
  KEY `vip_id` (`vip_id`),
  CONSTRAINT `jiagou_ibfk_1` FOREIGN KEY (`M_id`) REFERENCES `menu` (`M_id`),
  CONSTRAINT `jiagou_ibfk_2` FOREIGN KEY (`vip_id`) REFERENCES `vip_message` (`vip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jiagou
-- ----------------------------

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `M_id` int(20) NOT NULL AUTO_INCREMENT,
  `M_menu` varchar(20) NOT NULL,
  `M_price` decimal(10,1) NOT NULL,
  `M_image` varchar(255) DEFAULT NULL,
  `M_desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`M_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '美式咖啡', '24.0', 'ms.jpg', '“美式咖啡”（英文：Americano，意大利语：Caffè Americano）咖啡的一种，是最普通的咖啡。是使用滴滤式咖啡壶所制作出的黑咖啡，又或者是意式浓缩中加入大量的水制成。美式咖啡口味比较淡。因为一般的萃取时间相对较长（大概四五分钟），所以咖啡因含量较高。');
INSERT INTO `menu` VALUES ('3', '摩卡咖啡', '30.0', 'mk.jpg', '摩卡咖啡，英文是 Café Mocha，意思是巧克力咖啡,是意式拿铁咖啡 (Café Latté) 的变种。它通常是由三分之一的意式特浓咖啡(Caffè Espresso) 和三分之二的奶沫配成，不过它还会加入少量巧克力,巧克力通常会以巧克力糖浆的形式添加');
INSERT INTO `menu` VALUES ('4', '焦糖玛奇朵', '32.0', 'jtmqd.jpg', '焦糖玛奇朵（英文：Caramel Macchiato）是在香浓热牛奶上加入浓缩咖啡、香草，再淋上纯正焦糖而制成的饮品，融合三种不同口味。Macchiato意大利文，意思是“烙印”和“印染”，中文音译“玛奇朵”。“Caramel”意思是焦糖。焦糖玛琪朵，寓意“甜蜜的印记”。');
INSERT INTO `menu` VALUES ('5', '蓝山咖啡', '68.0', 'ls.jpg', ' 蓝山咖啡，是指由产自牙买加蓝山的咖啡豆冲泡而成的咖啡。此种咖啡拥有所有好咖啡的特点，不仅口味浓郁香醇，而且由于咖啡的甘、酸、苦三味搭配完美，所以完全不具苦味，仅有适度而完美的酸味。');
INSERT INTO `menu` VALUES ('6', '爱尔兰咖啡', '30.0', 'ael.jpg', '爱尔兰咖啡（Irish Coffee）是一款鸡尾酒，是以爱尔兰威士忌为基酒，配以咖啡为辅料，调制而成的一款鸡尾酒。相传，一位都柏林机场的酒保为了心仪的女孩，将威士忌融入热咖啡，首次调制成爱尔兰咖啡这款鸡尾酒');
INSERT INTO `menu` VALUES ('7', '可可', '18.0', 'coco.jpg', '可可是一种饮料，一般是热饮。典型的热巧克力由牛奶、巧克力或者可可粉和糖混合而成。一般热可可不含有可可脂，而热巧克力含有可可脂。热巧克力从新大陆引进欧洲后非常受欢迎。');
INSERT INTO `menu` VALUES ('8', '花式咖啡', '32.0', 'hskf.jpg', '花式咖啡是一款利用牛奶和咖啡制作而成的咖啡。通常会在表面精心制作各种各样的图案，在保证咖啡醇香的同时，增加咖啡的丝滑感和观赏性。');
INSERT INTO `menu` VALUES ('9', '拿铁咖啡', '30.0', 'nt.jpg', '拿铁咖啡需要一小杯意大利浓缩咖啡和一杯牛奶，拿铁咖啡中牛奶多而咖啡少。一般的拿铁咖啡的成分是三分之一的意式浓缩咖啡Espresso加三分之二的蒸鲜奶，一般不加入奶泡。');
INSERT INTO `menu` VALUES ('10', '樱花拿铁', '28.0', 'yhnt.jpg', '在拿铁咖啡的基础上，在奶泡层描绘樱花的图案，在不损咖啡醇香的同时，体验到樱花的香味中和咖啡的苦涩，加强观赏性');
INSERT INTO `menu` VALUES ('11', '抹茶拿铁', '28.0', 'mckf.jpg', '在拿铁咖啡的基础上，加入来自日本的抹茶粉，在奶泡层描绘图案，在不损咖啡醇香的同时，体验抹茶和拿铁交融的味道。');
INSERT INTO `menu` VALUES ('12', '玫瑰拿铁', '28.0', 'mgnt.jpg', '在拿铁咖啡的基础上，在奶泡层撒上些许的玫瑰花碎，在不损咖啡醇香的同时，体验到玫瑰的香味中和咖啡的苦涩，加强观赏性。');
INSERT INTO `menu` VALUES ('13', '焦糖海盐咖啡', '38.0', 'jthy.jpg', '在浓缩咖啡喝和蒸牛奶按照一定比例混合后，加入一定浓度的太妃榛果糖浆');
INSERT INTO `menu` VALUES ('14', '咖啡牛奶', '20.0', 'kn.jpg', '据说是1660年荷兰驻印尼巴达维雅城总督尼贺夫最早将咖啡与牛奶混合在一起饮用的咖啡牛奶，即在咖啡中加入大量的牛奶。飘香醇厚咖啡加上芳美浓郁的牛奶，两种经典饮品的绝妙搭配，两种滋味的碰撞，形成了具有双重口感享受的饮品。');
INSERT INTO `menu` VALUES ('15', '蜂蜜柠檬汁', '10.0', 'fmnm.jpg', '蜂蜜柠檬水，是以蜂蜜、柠檬为主要原料制成的饮品。口感酸甜，具有生津、减肥、止渴、祛暑、养颜、美容等功效。');
INSERT INTO `menu` VALUES ('16', '抹茶慕斯', '16.0', 'mcms.jpg', '抹茶慕斯采用抹茶与慕斯混合制作的一种甜点。慕斯英文mousse，是一种奶冻式的甜点，可以直接吃或做蛋糕夹层。通常是加入cream与凝固剂来造成浓稠冻状的效果。');
INSERT INTO `menu` VALUES ('17', '黑森林蛋糕', '18.0', 'hsl.jpg', '黑森林蛋糕(Schwarzwaelder Kirschtorte)是德国著名甜点，制作原料主要有脆饼面团底托、鲜奶油、樱桃酒等。是受德国法律保护的甜点之一，在德文里全名\"Schwarzwaelder\" 即为黑森林。它融合了樱桃的酸、奶油的甜、樱桃酒的醇香。');
INSERT INTO `menu` VALUES ('18', '提拉米苏', '17.0', 'tlms.jpg', '提拉米苏（Tiramisu）是一种带咖啡酒味儿的意大利甜点。以马斯卡彭芝士作为主要材料，再以手指饼干取代传统甜点的海绵蛋糕，加入咖啡、可可粉等其他材料。吃到嘴里香、滑、甜、腻、柔和中带有质感的变化，味道并不是一味的甜。在意大利文里提拉米苏（Tiramisu）的意思是“马上把我带走”，意指吃了此等美味，就会幸福得飘飘然、宛如登上仙境。');
INSERT INTO `menu` VALUES ('19', '蓝莓芝士蛋糕', '16.0', 'lmzs.jpg', '蓝莓芝士蛋糕口感香甜，颜色略微深沉但给人美感，经常配有蓝莓、紫葡萄等水果作为点缀。芝士蛋糕是指用芝士做的蛋糕。芝士又名奶酪、干酪，指动物乳经乳酸菌发酵或加酶后凝固，并除去乳清制成的浓缩乳制品。芝士本身主要由蛋白质、脂类等营养成分组成，同牛奶一样。');
INSERT INTO `menu` VALUES ('20', '葡式蛋挞', '15.0', 'dt.jpg', '葡式蛋挞，又称葡式奶油塔、焦糖玛琪朵蛋挞。港澳及广东地区称葡挞，是一种小型的奶油酥皮馅饼，属于蛋挞的一种，焦黑的表面为其特征。1989年，英国人安德鲁·史斗（Andrew Stow）将葡挞带到澳门，改用英式奶黄馅并减少糖的用量后，随即慕名而至者众，并成为澳门著名小吃，最为代表的是Milktar\'s 蛋挞。');
INSERT INTO `menu` VALUES ('21', '红丝绒蛋糕', '16.0', 'hsr.jpg', '丝绒蛋糕是一款甜点，制作原料主要有低筋面粉、鸡蛋、红曲粉、奶油等。冷却后，涂上奶油奶酪甜奶油霜。');
INSERT INTO `menu` VALUES ('22', '脏脏包', '17.0', 'zzb.jpg', '脏脏包正如其名，它看起来确实脏脏的，吃完后满嘴，满手都是脏的，就是用巧克力和面的起酥包脏脏包其实就是高级版的巧克力可颂，吃完以后嘴巴和手上会沾上巧克力而变 \" 脏 \" 因而得名 \" 脏脏包 \"');
INSERT INTO `menu` VALUES ('23', '马卡龙', '38.0', 'mkl.jpg', '马卡龙，又称作玛卡龙、法式小圆饼，是一种用蛋白、杏仁粉、白砂糖和糖霜制作，并夹有水果酱或奶油的法式甜点。口感丰富，外脆内柔，外观五彩缤纷，精致小巧。');
INSERT INTO `menu` VALUES ('24', '糖浆松糕布丁', '32.0', 'tjsgbd.jpg', '固执守旧到有点可爱的英国布丁，根据季节进行了明确的划分，夏天有新鲜草莓制成的冷不丁，冬天则是热乎乎的黄油味十足的太妃糖布丁。');
INSERT INTO `menu` VALUES ('25', '欧培拉', '35.0', 'opl.jpg', '欧培拉，法国知名甜点，是款有着数百年历史的蛋糕，那浓郁的巧克力与咖啡味令每个爱吃巧克力的人都迷恋不已。传统的欧培拉共有六层，其中包括三层浸过咖啡糖浆的海绵蛋糕和牛油、鲜奶油和巧克力奶油并以此做成的馅，充满咖啡与巧克力的香味，入口即化。');
INSERT INTO `menu` VALUES ('26', '波士顿派', '30.0', 'bsdp.jpg', '1856年一位名为Harvey D.Parker的人在波士顿开设了一家ParkerHouse餐馆，菜单上有一道含有巧克力糖浆的布丁派蛋糕，据说这就是我们今天所知道的波士顿派。');
INSERT INTO `menu` VALUES ('27', '舒芙蕾', '35.0', 'sfl.jpg', '舒芙蕾，也有译为梳乎厘，蛋奶酥。是一种源自法国的烹饪方法。这种特殊的厨艺方法，主要材料包括蛋黄及不同配料拌入经打匀后的蛋白，经烘焙质轻而蓬松。Soufflé一字来自法语中一个动词souffler的过去分词，意思是“使充气”或简单地指“蓬松地胀起来”。');

-- ----------------------------
-- Table structure for vip_message
-- ----------------------------
DROP TABLE IF EXISTS `vip_message`;
CREATE TABLE `vip_message` (
  `vip_id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_name` varchar(255) NOT NULL,
  `vip_password` varchar(255) NOT NULL,
  PRIMARY KEY (`vip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of vip_message
-- ----------------------------
INSERT INTO `vip_message` VALUES ('1', '', '');
INSERT INTO `vip_message` VALUES ('2', '王笑越', '');
INSERT INTO `vip_message` VALUES ('3', '仝森', '');
INSERT INTO `vip_message` VALUES ('4', '石欢', '');
INSERT INTO `vip_message` VALUES ('5', '姚云昭', '');
INSERT INTO `vip_message` VALUES ('6', '林冉', '123');
INSERT INTO `vip_message` VALUES ('7', '林冉', '123');
INSERT INTO `vip_message` VALUES ('8', '', '');
INSERT INTO `vip_message` VALUES ('9', '翠花', 'wjh');
INSERT INTO `vip_message` VALUES ('10', '石欢', '123');
